# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render
from django.http import HttpResponse, JsonResponse
from django.views.decorators.csrf import csrf_exempt
import feedparser
from rest_framework.renderers import JSONRenderer
from rest_framework.parsers import JSONParser
from .serializers import FeedSerializers
from .models import Feed


# def index(request):
#     return render(request, 'rss/reader.html')

def index(request):
    if request.GET.get("url"):
        url = request.GET["url"]
        feed = feedparser.parse(url)
    else:
        feed = None
    return render(request, 'rss/reader.html', {
           'feed': feed
    })




# def index(request):
#     if request.GET.get("urls"):
#         feed = feedparser.parse(request.GET.get("urls"))
#     else:
#         feed= None
#     return render(request,'rss/render.html',{'feed':feed})
# Create your views here.
@csrf_exempt
def rest_feeds(request):
    if request.method == "GET":
        feeds = Feed.objects.all()
        serializer = FeedSerializer(feeds, many=True)
        return JsonResponse(serializer.data, safe=False)
    elif request.method == "POST":
        data = JSONParser().parse(request)
        serializer = FeedSerializer(data=data)

        if serializer.is_valid():
            serializer.save()
            return JsonResponse(serializer.data, status=201)
        return JsonResponse(serializer.errors, status=400)

@csrf_exempt
def rest_feeds_detail(request,pk):
    try:
        feed=Feed.objects.get(pk=pk)
    except Feed.DoesNotExist:
        return HttpResponse(status=404)

    if __name__ == '__main__':
        if request.method =="GET":
            serializer = FeedSerializers(feed)
            return JsonResponse(serializer.data)
        elif request.method== "PUT":
            data= JSONParser().parse(request)
            serializer =FeedSerializers(feed,data=data)

            if serializer.is_valid():
                serializer.save()
                return JsonResponse(serializer.data)
            return JsonResponse(serializer.errors, status=400)
        elif request.method == "DELETE":
            feed.delete()
            return HttpResponse()

@csrf_exempt
def rest_items(request):
    feeds = Feed.objects.all()
    items = []
    for feed in feeds:
        rss = feedparser.parse(feed.url)
        try:
            items.extend(rss["items"])
        except KeyError:
            continue
    items = list(reversed(sorted(items, key=lambda item: item["published_parsed"])))
    return JsonResponse(items, safe=False)

