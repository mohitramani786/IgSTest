# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.test import TestCase
import json
from django.urls import reverse
from .models import Feed

class RssIndexviewTestcase(TestCase):
    def testnofeed(self):
        response= self.client.get(reverse("index"))

        self.assertEqual(response.status_code,200)
        self.assertEqual(response.context["feed"],None)

    def test_user_feed(self):
        response=self.client.get(reverse("index") + "?url=https://www.djangoproject.com/rss/weblog/")

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.context["feed"]['feed']['title'],'The Django weblog' )

class RssfeedModelsTest(TestCase):
    def setUp(self):
        Feed.objects.create("https://www.djangoproject.com/rss/weblog/")

    # def test_model_has_url(self):
    #     url="https://www.djangoproject.com/rss/weblog/"
    #     django_feed=Feed.objects.create(url=url)
    #     # self.assertEqual(django_feed.url,"https://www.djangoproject.com/rss/weblog/")

class RssRestFeedviewTests(TestCase):
    def test_create_feed(self):
        url="https://www.djangoproject.com/rss/weblog/"
        json_data= json.dumps({"url" : url})
        response=self.client.post(
            reverse("rest-feeds"),
            json_data,
            content_type="application/json"
        )
        feeds=Feed.objects.all()
        self.assertEqual(response.status_code,200)
        # self.assertQuerysetEqual(feeds,["<Feed '{}'>".format(url)])

    def test_update_feeds(self):
        url="https://www.djangoproject.com/rss/weblog/"
        new_url= "https://utan.io/?feed=rss2"
        Feed.objects.create(url=url)
        json_data= json.dumps({"url" : new_url})
        response= self.client.put(
            "/rss/feeds/1/",
            json_data,
            content_type="application/json"
        )
        feeds=Feed.objects.all()
        self.assertEqual(response.status_code,200)
        # self.assertQuerysetEqual(feeds,["<Feed '{}'>".format(new_url)])

    def delete_test_feed(self):
        Feed.objects.create(url="https://www.djangoproject.com/rss/weblog/")
        response=self.client.delete("rss/feeds/1")
        feeds=Feed.objects.all()
        self.assertEqual(response.status_code, 200)
        # self.assertQuerysetEqual(feeds, [])

class RssRestItemsViewTest(TestCase):
    def test_get_items(self):
        Feed.objects.create(url='https://www.djangoproject.com/rss/weblog/')
        response=self.client.get(reverse("rest-items"))
        self.assertEqual(response.status_code,200)


# Create your tests here.
